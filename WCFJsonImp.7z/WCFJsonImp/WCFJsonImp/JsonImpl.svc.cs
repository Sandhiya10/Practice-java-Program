﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace WCFJsonImp
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "JsonImpl" in code, svc and config file together.
    public class JsonImpl : IJsonImpl
    {
        public string GetValue(string ID)
        {
            return "Value is taken Successfully";
        }

        public void PostValue(string id)
        {
            DBClass db = new DBClass();
            int val = Convert.ToInt32(id);
            db.insert_HBeat(val);
        }
        

    }
}
