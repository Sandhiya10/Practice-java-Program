﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

namespace WCFJsonImp
{
    public class DBClass
    {
        public void insert_HBeat(int id)       {
            try
            { 
            SqlConnection conn = new SqlConnection("Data Source=ukwpidsql500i1.gdc-dev.net\\DEV_CL01_IN01, 10501;Initial Catalog=rpa_openspan;User ID=rpaopenspan;Password=hyyCU3Men;");
            conn.Open();
                SqlCommand cmd = new SqlCommand("insert into dbo.tbl_bot_hbeat (bot_id,hbeat) values(4,"+id+")",conn);
                cmd.ExecuteNonQuery();
                conn.Close();
        }
            catch(Exception e)
            {
                
            }

    }
    }
    
}



    

