﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.ServiceModel.Web;

namespace WCFJsonImp
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IJsonImpl" in both code and config file together.
    [ServiceContract]
    public interface IJsonImpl
    {
       
        [OperationContract]
        [WebInvoke(Method = "GET",UriTemplate = "/GetData/{Id}", BodyStyle = WebMessageBodyStyle.Wrapped,RequestFormat = WebMessageFormat.Json,ResponseFormat = WebMessageFormat.Json)]
        string GetValue(string Id);
        [WebInvoke(Method = "POST",
         UriTemplate = "/PostData/{ID}", BodyStyle = WebMessageBodyStyle.Bare,
         RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json)]
        void PostValue(string Id); 

    }

}
