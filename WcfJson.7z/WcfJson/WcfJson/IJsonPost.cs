﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace WcfJson
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IJsonPost" in both code and config file together.
    [ServiceContract]
    public interface IJsonPost
    {
        [OperationContract]
        [WebInvoke(UriTemplate = "/Insert",
           RequestFormat = WebMessageFormat.Json,
           ResponseFormat = WebMessageFormat.Json, Method = "POST", BodyStyle = WebMessageBodyStyle.WrappedRequest)

       ] 
        bool insertVal(Data d);
        [WebGet(UriTemplate = "/GetName/{id}",
           RequestFormat = WebMessageFormat.Json,
           ResponseFormat = WebMessageFormat.Json)]
        Data getNameByID(string ID);
    }
}
