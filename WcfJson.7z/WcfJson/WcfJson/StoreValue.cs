﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WcfJson
{
    public class StoreValue
    {
        public List<Data> list = new List<Data>();
       public void setValue(Data d)
        {
            list.Add(d);
        }
       public Data getValue(string id)
       {
           Data result=new Data();

           foreach (var t in list)
           {
               if (t.ID== id)
               result=t;
           }
           return result;
       }
    }
}