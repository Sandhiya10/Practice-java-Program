﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using Newtonsoft.Json;
using System.Xml.Linq;
namespace WcfJson
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "JsonPost" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select JsonPost.svc or JsonPost.svc.cs at the Solution Explorer and start debugging.
    public class JsonPost : IJsonPost
    {
       
        public bool insertVal(Data d)
        {
          /*  try
            {
                File.WriteAllText(@"c:\users\sandhiya\documents\visual studio 2012\Projects\WcfJson\WcfJson\Input.json", JsonConvert.SerializeObject(d));
                using (StreamWriter file = File.CreateText(@"c:\users\sandhiya\documents\visual studio 2012\Projects\WcfJson\WcfJson\Input.json"))
                {
                    JsonSerializer serializer = new JsonSerializer();
                    serializer.Serialize(file, d);
                }
            }
            catch (Exception e)
            { }
            return true;
           */
            try
            {
                XDocument doc = XDocument.Load(@"c:\users\sandhiya\documents\visual studio 2012\Projects\WcfJson\WcfJson\Values.xml");

                doc.Element("DocumentElement").Add(
                        new XElement("Data",
                        new XElement("ID", d.ID),
                        new XElement("Name", d.Name)
                       ));

                doc.Save(@"c:\users\sandhiya\documents\visual studio 2012\Projects\WcfJson\WcfJson\Values.xml");
            }
            catch (Exception ex)
            {
                throw new FaultException<string>
                     (ex.Message);
            }
            return true;
        }
        public Data getNameByID(string ID)
        {
          Data d=new Data();
          return d;
        }
    }
}
