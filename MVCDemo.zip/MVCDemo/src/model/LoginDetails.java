package model;

public class LoginDetails {

private	String UserName,Password;

public String getUserName() {
	return UserName;
}

public void setUserName(String userName) {
	UserName = userName;
}

public String getPassword() {
	return Password;
}

public void setPassword(String password) {
	Password = password;
}
public boolean isLoginValid()
{
	if((UserName.equals("NIIT"))&&(Password.equals("12345")))
	{
	return true;
	}
	else
	{
	return false;
	}
}
}
